#ifndef DIALOGWARNING1_H
#define DIALOGWARNING1_H

#include <QDialog>

namespace Ui {
class DialogWarning1;
}

class DialogWarning1 : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogWarning1(QWidget *parent = 0);
    ~DialogWarning1();
    
private slots:
    void on_aceptar_clicked();

private:
    Ui::DialogWarning1 *ui;
};

#endif // DIALOGWARNING1_H
