#ifndef DIALOGALTAESTADOCIVIL_H
#define DIALOGALTAESTADOCIVIL_H

#include <QDialog>

namespace Ui {
class DialogAltaEstadoCivil;
}

class DialogAltaEstadoCivil : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltaEstadoCivil(QWidget *parent = 0);
    ~DialogAltaEstadoCivil();

    void addEstadoCivil();
    
private slots:
    void on_salir_clicked();

    void on_agregar_clicked();

private:
    Ui::DialogAltaEstadoCivil *ui;
};

#endif // DIALOGALTAESTADOCIVIL_H
