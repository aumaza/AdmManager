#include "dialogbajas.h"
#include "ui_dialogbajas.h"
#include <QPixmap>

DialogBajas::DialogBajas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogBajas)
{
    ui->setupUi(this);
    setWindowTitle("Modulo Bajas");
}

DialogBajas::~DialogBajas()
{
    delete ui;
}
