#ifndef DIALOGWARNING3_H
#define DIALOGWARNING3_H

#include <QDialog>

namespace Ui {
class DialogWarning3;
}

class DialogWarning3 : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogWarning3(QWidget *parent = 0);
    ~DialogWarning3();
    
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::DialogWarning3 *ui;
};

#endif // DIALOGWARNING3_H
