#include "dialogaltacat.h"
#include "ui_dialogaltacat.h"
#include "dialogwarning1.h"
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

DialogAltaCat::DialogAltaCat(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltaCat)
{
    ui->setupUi(this);
    setWindowTitle("Alta Categoria");
}

DialogAltaCat::~DialogAltaCat()
{
    delete ui;
}

void DialogAltaCat::addCategoria()
{
    QString consulta;
    consulta.append("INSERT INTO categorias ("
                    "descripcion,"
                    "salario"
                    ")"
                    "VALUES("
                    "'"+ui->descripcion->text()+"',"
                    ""+ui->salario->text()+""
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "Register has been insert Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}

void DialogAltaCat::on_salir_clicked()
{
    close();
}

void DialogAltaCat::on_agregar_clicked()
{
    addCategoria();
    DialogWarning1 w;
    w.exec();
    ui->descripcion->clear();
    ui->salario->clear();
}
