#ifndef DIALOGALTAS_H
#define DIALOGALTAS_H

#include <QDialog>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

namespace Ui {
class DialogAltas;
}

class DialogAltas : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltas(QWidget *parent = 0);
    ~DialogAltas();

    void crearTablaEmpleados();
    void crearTablaEstudios();
    void crearTablaNacionalidad();
    void crearTablaEstadoCivil();
    void crearTablaCategorias();
    void crearTablaCursosRealizados();
    void crearTablaTipoBaja();
    
private slots:
    void on_pushButton_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_4_clicked();


private:
    Ui::DialogAltas *ui;
    QSqlDatabase db;
};

#endif // DIALOGALTAS_H
