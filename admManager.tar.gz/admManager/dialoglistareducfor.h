#ifndef DIALOGLISTAREDUCFOR_H
#define DIALOGLISTAREDUCFOR_H

#include <QDialog>

namespace Ui {
class DialogListarEducFor;
}

class DialogListarEducFor : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarEducFor(QWidget *parent = 0);
    ~DialogListarEducFor();

    void listarEducFor();
    
private slots:
    void on_pushButton_clicked();

private:
    Ui::DialogListarEducFor *ui;
};

#endif // DIALOGLISTAREDUCFOR_H
