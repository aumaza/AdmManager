#ifndef DIALOGLISTARNACIONALIDAD_H
#define DIALOGLISTARNACIONALIDAD_H

#include <QDialog>

namespace Ui {
class DialogListarNacionalidad;
}

class DialogListarNacionalidad : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarNacionalidad(QWidget *parent = 0);
    ~DialogListarNacionalidad();

    void listarNacionalidad();
    
private slots:
    void on_pushButton_clicked();

private:
    Ui::DialogListarNacionalidad *ui;
};

#endif // DIALOGLISTARNACIONALIDAD_H
