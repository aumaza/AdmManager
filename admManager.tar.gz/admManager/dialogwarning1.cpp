#include "dialogwarning1.h"
#include "ui_dialogwarning1.h"

DialogWarning1::DialogWarning1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogWarning1)
{
    ui->setupUi(this);
}

DialogWarning1::~DialogWarning1()
{
    delete ui;
}

void DialogWarning1::on_aceptar_clicked()
{
    close();
}
