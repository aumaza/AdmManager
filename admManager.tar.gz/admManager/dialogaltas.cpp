#include "dialogaltas.h"
#include "ui_dialogaltas.h"
#include "dialogaltaempleado.h"
#include "dialogaltacat.h"
#include "dialogcursosrealizados.h"
#include "dialogeducform.h"
#include "dialogaltanac.h"
#include "dialogaltatipobaja.h"
#include "dialogaltaestadocivil.h"
#include "dialogwarning2.h"
#include "dialogwarning3.h"
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>


DialogAltas::DialogAltas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltas)
{
    ui->setupUi(this);
    setWindowTitle("Modulo Altas");



   /* QString name;
    name.append("sqlBase1.sqlite");

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(name);

    if(db.open())
    {
        DialogWarning2 wa;
        wa.exec();
        //ui->statusBar->showMessage("Running Application... Connection Succesfully");
        qDebug() << "Connection Succesfully";
    }

    else
    {
        DialogWarning3 warning;
        warning.exec();
        //ui->statusBar->showMessage("Connection ERROR!");
        qDebug()<<"Connection ERROR!";
    }

    crearTablaEmpleados();
    crearTablaEstudios();
    crearTablaNacionalidad();
    crearTablaEstadoCivil();
    crearTablaCategorias();
    crearTablaCursosRealizados();
    crearTablaTipoBaja();*/
}


//ACCIONES SOBRE BOTONES
//=====================================================
DialogAltas::~DialogAltas()
{    
    delete ui;
}

void DialogAltas::on_pushButton_clicked()
{
    DialogAltaEmpleado A(this);
    A.exec();
}

void DialogAltas::on_pushButton_5_clicked()
{
    DialogAltaCat C(this);
    C.exec();
}

void DialogAltas::on_pushButton_6_clicked()
{
    DialogCursosRealizados cr(this);
    cr.exec();
}

void DialogAltas::on_pushButton_2_clicked()
{
    DialogEducForm ed(this);
    ed.exec();
}

void DialogAltas::on_pushButton_3_clicked()
{
    DialogAltaNac na(this);
    na.exec();
}

void DialogAltas::on_pushButton_7_clicked()
{
    DialogAltaTipoBaja tb(this);
    tb.exec();
}

void DialogAltas::on_pushButton_4_clicked()
{
    DialogAltaEstadoCivil ec(this);
    ec.exec();
}


//FUNCIONES
//===================================

/*void DialogAltas::crearTablaEmpleados()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS empleados ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "nombre VARCHAR(35),"
                    "apellido VARCHAR(35),"
                    "edad INTEGER NOT NULL,"
                    "dni VARCHAR(9),"
                    "nacionalidad VARCHAR(35),"
                    "estudios VARCHAR(35),"
                    "estadoCivil VARCHAR(35),"
                    "cantHijos INTEGER NOT NULL,"
                    "fechaIngreso INTEGER NOT NULL,"
                    "antiguedad INTEGER NOT NULL"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table EMPLEADOS Already Exists or Creates Succesfully");
        qDebug() << "Table EMPLEADOS Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}


void DialogAltas::crearTablaEstudios()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS estudios ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "descripcion VARCHAR(35)"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table ESTUDIOS Already Exists or Creates Succesfully");
        qDebug() << "Table ESTUDIOS Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}

void DialogAltas::crearTablaNacionalidad()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS nacionalidad ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "descripcion VARCHAR(35)"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table NACIONALIDAD Already Exists or Creates Succesfully");
        qDebug() << "Table NACIONALIDAD Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}

void DialogAltas::crearTablaEstadoCivil()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS estadoCivil ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "descripcion VARCHAR(35)"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table ESTADO CIVIL Already Exists or Creates Succesfully");
        qDebug() << "Table ESTADO CIVIL Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}

void DialogAltas::crearTablaCategorias()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS categorias ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "descripcion VARCHAR(35),"
                    "salario INTEGER NOT NULL"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table CATEGORIAS Already Exists or Creates Succesfully");
        qDebug() << "Table CATEGORIAS Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}

void DialogAltas::crearTablaCursosRealizados()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS cursosRealizados ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "empleado INTEGER NOT NULL,"
                    "curso VARCHAR(100),"
                    "fechaFinal INTEGER NOT NULL"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table CURSOS REALIZADOS Already Exists or Creates Succesfully");
        qDebug() << "Table CURSOS REALIZADOS Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}

void DialogAltas::crearTablaTipoBaja()
{
    QString consulta;
    consulta.append("CREATE TABLE IF NOT EXISTS tipoBaja ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    "descripcion VARCHAR(35)"
                    ");");
    QSqlQuery crear;
    crear.prepare(consulta);

    if(crear.exec())
    {

       //ui->statusBar->showMessage("Table TIPO DE BAJA Already Exists or Creates Succesfully");
        qDebug() << "Table TIPO DE BAJA Already Exists or Creates Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible Creates Table");
        qDebug()<<"ERROR! Impossible Creates Table";
        qDebug()<<"ERROR!"<< crear.lastError();
    }
}*/
