#include "dialogaltaempleado.h"
#include "ui_dialogaltaempleado.h"
#include "dialogwarning1.h"
#include <QtCore/QString>
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogAltaEmpleado::DialogAltaEmpleado(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltaEmpleado)
{
    ui->setupUi(this);
    setWindowTitle("Alta Empleado");


}

DialogAltaEmpleado::~DialogAltaEmpleado()
{
    delete ui;
}

void DialogAltaEmpleado::addEmpleado()
{

    QString consulta;
    consulta.append("INSERT INTO empleados ("
                    "nombre,"
                    "apellido,"
                    "edad,"
                    "dni,"
                    "nacionalidad,"
                    "estudios,"
                    "estadoCivil,"
                    "cantHijos,"
                    "fechaIngreso,"
                    "antiguedad)"
                    "VALUES("
                    "'"+ui->nombre->text()+"',"
                    "'"+ui->apellido->text()+"',"
                    ""+ui->edad->text()+","
                    "'"+ui->dni->text()+"',"
                    "'"+ui->nacionalidad->currentText()+"',"
                    "'"+ui->estudios->currentText()+"',"
                    "'"+ui->estadocivil->currentText()+"',"
                    ""+ui->canthijos->text()+","
                    ""+ui->fecha->text()+","
                    ""+ui->antiguedad->text()+""
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "User has been insert Succesfully";

    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}




void DialogAltaEmpleado::on_agregar_clicked()
{
    addEmpleado();
    DialogWarning1 w;
    w.exec();
    ui->nombre->clear();
    ui->apellido->clear();
    ui->edad->clear();
    ui->dni->clear();
    ui->canthijos->clear();
    ui->antiguedad->clear();
}



void DialogAltaEmpleado::on_salir_clicked()
{
    close();
}
