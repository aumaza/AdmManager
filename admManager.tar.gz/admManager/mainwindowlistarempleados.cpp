#include "mainwindowlistarempleados.h"
#include "ui_mainwindowlistarempleados.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

MainWindowListarEmpleados::MainWindowListarEmpleados(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowListarEmpleados)
{
    ui->setupUi(this);
}

MainWindowListarEmpleados::~MainWindowListarEmpleados()
{
    delete ui;
    mostrarDatos();
}

void MainWindowListarEmpleados::mostrarDatos()
{
    QString consulta;
    consulta.append("SELECT * FROM empleados");
    QSqlQuery consultar;
    consultar.prepare(consulta);


    if(consultar.exec())
    {
        ui->statusBar->showMessage("All registers are shown Succesfully...Waiting for more...");

        qDebug() << "All registers are shown Succesfully";
    }

    else
    {
        ui->statusBar->showMessage("ERROR! Impossible show table registers...");
        qDebug()<<"ERROR! Impossible show table registers...";
        qDebug()<<"ERROR!"<< consultar.lastError();
    }

    int fila = 0;
    ui->lista->setRowCount(0);
    while(consultar.next())
    {
        ui->lista->insertRow(fila);
        ui->lista->setItem(fila,0,new QTableWidgetItem(consultar.value(1).toByteArray().constData()));
        ui->lista->setItem(fila,1,new QTableWidgetItem(consultar.value(2).toByteArray().constData()));
        ui->lista->setItem(fila,2,new QTableWidgetItem(consultar.value(3).toByteArray().constData()));
        ui->lista->setItem(fila,3,new QTableWidgetItem(consultar.value(4).toByteArray().constData()));
        ui->lista->setItem(fila,4,new QTableWidgetItem(consultar.value(5).toByteArray().constData()));
        ui->lista->setItem(fila,5,new QTableWidgetItem(consultar.value(6).toByteArray().constData()));
        ui->lista->setItem(fila,6,new QTableWidgetItem(consultar.value(7).toByteArray().constData()));
        ui->lista->setItem(fila,7,new QTableWidgetItem(consultar.value(8).toByteArray().constData()));
        ui->lista->setItem(fila,8,new QTableWidgetItem(consultar.value(9).toByteArray().constData()));
        ui->lista->setItem(fila,9,new QTableWidgetItem(consultar.value(10).toByteArray().constData()));
        ui->lista->setItem(fila,10,new QTableWidgetItem(consultar.value(11).toByteArray().constData()));
        fila++;
    }
}

void MainWindowListarEmpleados::on_aceptar_clicked()
{
    close();
}


