#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlError>
#include <QtSql/QSqlQuery>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void crearTablaEmpleados();
    void crearTablaEstudios();
    void crearTablaNacionalidad();
    void crearTablaEstadoCivil();
    void crearTablaCategorias();
    void crearTablaCursosRealizados();
    void crearTablaTipoBaja();
    
private slots:
    void on_mAltas_clicked();

    void on_mMod_clicked();

    void on_MBajas_clicked();

    void on_mInfo_clicked();

    void on_mSueldos_clicked();

    void on_salir_clicked();

private:
    Ui::MainWindow *ui;
    QSqlDatabase db;
};

#endif // MAINWINDOW_H
