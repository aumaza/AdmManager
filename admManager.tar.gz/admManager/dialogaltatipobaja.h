#ifndef DIALOGALTATIPOBAJA_H
#define DIALOGALTATIPOBAJA_H

#include <QDialog>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

namespace Ui {
class DialogAltaTipoBaja;
}

class DialogAltaTipoBaja : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltaTipoBaja(QWidget *parent = 0);
    ~DialogAltaTipoBaja();

    void addTipoBaja();
    
private slots:
    void on_salir_clicked();

    void on_agregar_clicked();

private:
    Ui::DialogAltaTipoBaja *ui;
};

#endif // DIALOGALTATIPOBAJA_H
