#ifndef DIALOGWARNING2_H
#define DIALOGWARNING2_H

#include <QDialog>

namespace Ui {
class DialogWarning2;
}

class DialogWarning2 : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogWarning2(QWidget *parent = 0);
    ~DialogWarning2();
    
private slots:



    void on_aceptar_clicked();

private:
    Ui::DialogWarning2 *ui;
};

#endif // DIALOGWARNING2_H
