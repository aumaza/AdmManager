#ifndef MAINWINDOWLISTAREMPLEADOS_H
#define MAINWINDOWLISTAREMPLEADOS_H

#include <QMainWindow>

namespace Ui {
class MainWindowListarEmpleados;
}

class MainWindowListarEmpleados : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindowListarEmpleados(QWidget *parent = 0);
    ~MainWindowListarEmpleados();

    void mostrarDatos();
    
private slots:
    void on_aceptar_clicked();

private:
    Ui::MainWindowListarEmpleados *ui;
};


#endif // MAINWINDOWLISTAREMPLEADOS_H
