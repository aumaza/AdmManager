#include "dialogaltatipobaja.h"
#include "ui_dialogaltatipobaja.h"
#include "dialogwarning1.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

DialogAltaTipoBaja::DialogAltaTipoBaja(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltaTipoBaja)
{
    ui->setupUi(this);
    setWindowTitle("Alta Tipo de Baja");
}

DialogAltaTipoBaja::~DialogAltaTipoBaja()
{
    delete ui;
}

void DialogAltaTipoBaja::addTipoBaja()
{
    QString consulta;
    consulta.append("INSERT INTO tipoBaja ("
                    "descripcion"
                    ")"
                    "VALUES("
                    "'"+ui->descripcion->text()+"'"
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "Register has been insert Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}

void DialogAltaTipoBaja::on_salir_clicked()
{
    close();
}

void DialogAltaTipoBaja::on_agregar_clicked()
{
    addTipoBaja();
    DialogWarning1 w;
    w.exec();
    ui->descripcion->clear();
}


