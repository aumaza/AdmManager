#include "dialogcursosrealizados.h"
#include "ui_dialogcursosrealizados.h"
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

DialogCursosRealizados::DialogCursosRealizados(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCursosRealizados)
{
    ui->setupUi(this);
}

DialogCursosRealizados::~DialogCursosRealizados()
{
    delete ui;
}

void DialogCursosRealizados::addCursosRealizados()
{
    QString consulta;
    consulta.append("INSERT INTO cursosRealizados ("
                    "empleado,"
                    "curso,"
                    "fechaFinal"
                    ")"
                    "VALUES("
                    "'"+ui->empleado->currentText()+"',"
                    "'"+ui->curso->text()+"',"
                    ""+ui->date->text()+""
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "Register has been insert Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}

void DialogCursosRealizados::on_salir_clicked()
{
    close();
}


