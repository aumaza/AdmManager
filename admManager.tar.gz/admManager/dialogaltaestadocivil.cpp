#include "dialogaltaestadocivil.h"
#include "ui_dialogaltaestadocivil.h"
#include "dialogwarning1.h"
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

DialogAltaEstadoCivil::DialogAltaEstadoCivil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltaEstadoCivil)
{
    ui->setupUi(this);
    setWindowTitle("Alta Estado Civil");
}

DialogAltaEstadoCivil::~DialogAltaEstadoCivil()
{
    delete ui;
}

void DialogAltaEstadoCivil::addEstadoCivil()
{
    QString consulta;
    consulta.append("INSERT INTO estadoCivil ("
                    "descripcion"
                    ")"
                    "VALUES("
                    "'"+ui->estado->text()+"'"
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "Register has been insert Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}



void DialogAltaEstadoCivil::on_salir_clicked()
{
    close();
}

void DialogAltaEstadoCivil::on_agregar_clicked()
{
    addEstadoCivil();
    DialogWarning1 w;
    w.exec();
    ui->estado->clear();
}
