#include "dialoglistarestadocivil.h"
#include "ui_dialoglistarestadocivil.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogListarEstadoCivil::DialogListarEstadoCivil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogListarEstadoCivil)
{
    ui->setupUi(this);
    listarEstadoCivil();
}

DialogListarEstadoCivil::~DialogListarEstadoCivil()
{
    delete ui;
}

void DialogListarEstadoCivil::listarEstadoCivil()
{
    QString consulta;
    consulta.append("SELECT * FROM estadoCivil");
    QSqlQuery consultar;
    consultar.prepare(consulta);


    if(consultar.exec())
    {
        //ui->message->text("All registers are shown Succesfully...Waiting for more...");

        qDebug() << "All registers are shown Succesfully";
    }

    else
    {
       // ui->message->text("ERROR! Impossible show table registers...");
        qDebug()<<"ERROR! Impossible show table registers...";
        qDebug()<<"ERROR!"<< consultar.lastError();
    }

    int fila = 0;
    ui->tableWidget->setRowCount(0);
    while(consultar.next())
    {
        ui->tableWidget->insertRow(fila);
        ui->tableWidget->setItem(fila,0,new QTableWidgetItem(consultar.value(1).toByteArray().constData()));
        ui->tableWidget->setItem(fila,1,new QTableWidgetItem(consultar.value(2).toByteArray().constData()));

        fila++;
    }
}

void DialogListarEstadoCivil::on_pushButton_2_clicked()
{
    accept();
}
