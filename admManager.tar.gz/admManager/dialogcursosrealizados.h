#ifndef DIALOGCURSOSREALIZADOS_H
#define DIALOGCURSOSREALIZADOS_H

#include <QDialog>

namespace Ui {
class DialogCursosRealizados;
}

class DialogCursosRealizados : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogCursosRealizados(QWidget *parent = 0);
    ~DialogCursosRealizados();

    void addCursosRealizados();
    
private slots:
    void on_salir_clicked();

private:
    Ui::DialogCursosRealizados *ui;
};

#endif // DIALOGCURSOSREALIZADOS_H
