#ifndef DIALOGLISTARESTADOCIVIL_H
#define DIALOGLISTARESTADOCIVIL_H

#include <QDialog>

namespace Ui {
class DialogListarEstadoCivil;
}

class DialogListarEstadoCivil : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarEstadoCivil(QWidget *parent = 0);
    ~DialogListarEstadoCivil();

    void listarEstadoCivil();
    
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::DialogListarEstadoCivil *ui;
};

#endif // DIALOGLISTARESTADOCIVIL_H
