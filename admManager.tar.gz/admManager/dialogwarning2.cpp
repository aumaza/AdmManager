#include "dialogwarning2.h"
#include "ui_dialogwarning2.h"

DialogWarning2::DialogWarning2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogWarning2)
{
    ui->setupUi(this);
    setWindowTitle("SQL DB Connection");
}

DialogWarning2::~DialogWarning2()
{
    delete ui;
}




void DialogWarning2::on_aceptar_clicked()
{
    accept();
}
