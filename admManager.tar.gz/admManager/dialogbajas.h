#ifndef DIALOGBAJAS_H
#define DIALOGBAJAS_H

#include <QDialog>

namespace Ui {
class DialogBajas;
}

class DialogBajas : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogBajas(QWidget *parent = 0);
    ~DialogBajas();
    
private:
    Ui::DialogBajas *ui;
};

#endif // DIALOGBAJAS_H
