#ifndef DIALOGSUELDOS_H
#define DIALOGSUELDOS_H

#include <QDialog>

namespace Ui {
class DialogSueldos;
}

class DialogSueldos : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogSueldos(QWidget *parent = 0);
    ~DialogSueldos();
    
private:
    Ui::DialogSueldos *ui;
};

#endif // DIALOGSUELDOS_H
