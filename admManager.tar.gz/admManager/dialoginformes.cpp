#include "dialoginformes.h"
#include "ui_dialoginformes.h"
#include "dialoglistarempleados.h"
#include "dialoglistarnacionalidad.h"
#include "dialoglistareducfor.h"
#include "dialoglistarestadocivil.h"
#include "dialoglistarcategorias.h"
#include "dialoglistartipobaja.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogInformes::DialogInformes(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogInformes)
{
    ui->setupUi(this);
    setWindowTitle("Modulo Informes");
}

DialogInformes::~DialogInformes()
{
    delete ui;
}

void DialogInformes::on_pushButton_clicked()
{
    DialogListarEmpleados lista;
    lista.exec();

}

void DialogInformes::on_pushButton_3_clicked()
{
    DialogListarNacionalidad n;
    n.exec();
}



void DialogInformes::on_pushButton_2_clicked()
{
    DialogListarEducFor e;
    e.exec();
}

void DialogInformes::on_pushButton_4_clicked()
{
    DialogListarEstadoCivil ec;
    ec.exec();
}

void DialogInformes::on_pushButton_5_clicked()
{
    DialogListarCategorias cat;
    cat.exec();
}



void DialogInformes::on_pushButton_7_clicked()
{
    DialogListarTipoBaja tb;
    tb.exec();
}
