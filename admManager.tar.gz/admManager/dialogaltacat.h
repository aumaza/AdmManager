#ifndef DIALOGALTACAT_H
#define DIALOGALTACAT_H

#include <QDialog>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

namespace Ui {
class DialogAltaCat;
}

class DialogAltaCat : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltaCat(QWidget *parent = 0);
    ~DialogAltaCat();

    void addCategoria();
    
private slots:
    void on_salir_clicked();

    void on_agregar_clicked();

private:
    Ui::DialogAltaCat *ui;
    QSqlDatabase db;
};

#endif // DIALOGALTACAT_H
