/********************************************************************************
** Form generated from reading UI file 'dialogsueldos.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGSUELDOS_H
#define UI_DIALOGSUELDOS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogSueldos
{
public:
    QLabel *label;
    QFrame *line;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *DialogSueldos)
    {
        if (DialogSueldos->objectName().isEmpty())
            DialogSueldos->setObjectName(QString::fromUtf8("DialogSueldos"));
        DialogSueldos->resize(400, 300);
        label = new QLabel(DialogSueldos);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 10, 151, 41));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setFrameShape(QFrame::StyledPanel);
        label->setFrameShadow(QFrame::Sunken);
        label->setAlignment(Qt::AlignCenter);
        line = new QFrame(DialogSueldos);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(100, 50, 201, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        widget = new QWidget(DialogSueldos);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(120, 80, 161, 161));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);


        retranslateUi(DialogSueldos);

        QMetaObject::connectSlotsByName(DialogSueldos);
    } // setupUi

    void retranslateUi(QDialog *DialogSueldos)
    {
        DialogSueldos->setWindowTitle(QApplication::translate("DialogSueldos", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogSueldos", "Modulo Sueldos", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogSueldos", "Liquidar Haberes", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DialogSueldos", "Liquidar Vacaciones", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("DialogSueldos", "Liquidar Aguinaldo", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("DialogSueldos", "Liquidaci\303\263n Final", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogSueldos: public Ui_DialogSueldos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGSUELDOS_H
