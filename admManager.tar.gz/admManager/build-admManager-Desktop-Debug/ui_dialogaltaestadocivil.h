/********************************************************************************
** Form generated from reading UI file 'dialogaltaestadocivil.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGALTAESTADOCIVIL_H
#define UI_DIALOGALTAESTADOCIVIL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogAltaEstadoCivil
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *estado;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *agregar;
    QPushButton *salir;

    void setupUi(QDialog *DialogAltaEstadoCivil)
    {
        if (DialogAltaEstadoCivil->objectName().isEmpty())
            DialogAltaEstadoCivil->setObjectName(QString::fromUtf8("DialogAltaEstadoCivil"));
        DialogAltaEstadoCivil->resize(390, 221);
        widget = new QWidget(DialogAltaEstadoCivil);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(50, 40, 271, 91));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/meeting-attending.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        estado = new QLineEdit(widget);
        estado->setObjectName(QString::fromUtf8("estado"));
        estado->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(estado);


        verticalLayout->addLayout(horizontalLayout);

        widget1 = new QWidget(DialogAltaEstadoCivil);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(70, 150, 211, 27));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        agregar = new QPushButton(widget1);
        agregar->setObjectName(QString::fromUtf8("agregar"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/list-add.png"), QSize(), QIcon::Active, QIcon::On);
        agregar->setIcon(icon1);

        horizontalLayout_2->addWidget(agregar);

        salir = new QPushButton(widget1);
        salir->setObjectName(QString::fromUtf8("salir"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::On);
        salir->setIcon(icon2);

        horizontalLayout_2->addWidget(salir);


        retranslateUi(DialogAltaEstadoCivil);

        QMetaObject::connectSlotsByName(DialogAltaEstadoCivil);
    } // setupUi

    void retranslateUi(QDialog *DialogAltaEstadoCivil)
    {
        DialogAltaEstadoCivil->setWindowTitle(QApplication::translate("DialogAltaEstadoCivil", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogAltaEstadoCivil", "Cargar Estado Civil", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogAltaEstadoCivil", "Descripci\303\263n", 0, QApplication::UnicodeUTF8));
        agregar->setText(QApplication::translate("DialogAltaEstadoCivil", "Agregar", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("DialogAltaEstadoCivil", "Salir", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogAltaEstadoCivil: public Ui_DialogAltaEstadoCivil {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGALTAESTADOCIVIL_H
