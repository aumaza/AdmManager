/********************************************************************************
** Form generated from reading UI file 'mainwindowlistarempleados.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWLISTAREMPLEADOS_H
#define UI_MAINWINDOWLISTAREMPLEADOS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QListView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowListarEmpleados
{
public:
    QWidget *centralwidget;
    QListView *lista;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QFrame *line;
    QPushButton *aceptar;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindowListarEmpleados)
    {
        if (MainWindowListarEmpleados->objectName().isEmpty())
            MainWindowListarEmpleados->setObjectName(QString::fromUtf8("MainWindowListarEmpleados"));
        MainWindowListarEmpleados->resize(800, 600);
        centralwidget = new QWidget(MainWindowListarEmpleados);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lista = new QListView(centralwidget);
        lista->setObjectName(QString::fromUtf8("lista"));
        lista->setGeometry(QRect(30, 20, 731, 451));
        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(270, 470, 241, 81));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        line = new QFrame(widget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        aceptar = new QPushButton(widget);
        aceptar->setObjectName(QString::fromUtf8("aceptar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-ok.png"), QSize(), QIcon::Active, QIcon::On);
        aceptar->setIcon(icon);

        verticalLayout->addWidget(aceptar);

        MainWindowListarEmpleados->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindowListarEmpleados);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 20));
        MainWindowListarEmpleados->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindowListarEmpleados);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindowListarEmpleados->setStatusBar(statusbar);

        retranslateUi(MainWindowListarEmpleados);

        QMetaObject::connectSlotsByName(MainWindowListarEmpleados);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowListarEmpleados)
    {
        MainWindowListarEmpleados->setWindowTitle(QApplication::translate("MainWindowListarEmpleados", "MainWindow", 0, QApplication::UnicodeUTF8));
        aceptar->setText(QApplication::translate("MainWindowListarEmpleados", "Aceptar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindowListarEmpleados: public Ui_MainWindowListarEmpleados {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWLISTAREMPLEADOS_H
