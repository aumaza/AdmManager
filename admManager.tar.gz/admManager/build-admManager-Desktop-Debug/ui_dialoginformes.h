/********************************************************************************
** Form generated from reading UI file 'dialoginformes.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGINFORMES_H
#define UI_DIALOGINFORMES_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogInformes
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton_8;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;

    void setupUi(QDialog *DialogInformes)
    {
        if (DialogInformes->objectName().isEmpty())
            DialogInformes->setObjectName(QString::fromUtf8("DialogInformes"));
        DialogInformes->resize(391, 371);
        layoutWidget = new QWidget(DialogInformes);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 20, 208, 321));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(layoutWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/view-calendar-timeline.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_8->setIcon(icon);
        pushButton_8->setIconSize(QSize(32, 32));

        verticalLayout_2->addWidget(pushButton_8);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/meeting-attending-tentative.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon1);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-education-university.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_2->setIcon(icon2);
        pushButton_2->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-education-language.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_3->setIcon(icon3);
        pushButton_3->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/meeting-attending.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_4->setIcon(icon4);
        pushButton_4->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-engineering.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_5->setIcon(icon5);
        pushButton_5->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(layoutWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-education-school.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_6->setIcon(icon6);
        pushButton_6->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_6);

        pushButton_7 = new QPushButton(layoutWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/apps/kthesaurus.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_7->setIcon(icon7);
        pushButton_7->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton_7);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(DialogInformes);

        QMetaObject::connectSlotsByName(DialogInformes);
    } // setupUi

    void retranslateUi(QDialog *DialogInformes)
    {
        DialogInformes->setWindowTitle(QApplication::translate("DialogInformes", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton_8->setText(QApplication::translate("DialogInformes", "Modulo Informes", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogInformes", "Listar Empleados", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DialogInformes", "Listar Educacion Formal", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("DialogInformes", "Listar Nacionalidad", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("DialogInformes", "Listar Estado Civil", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("DialogInformes", "Listar Categorias", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("DialogInformes", "Listar Cursos Realizados", 0, QApplication::UnicodeUTF8));
        pushButton_7->setText(QApplication::translate("DialogInformes", "Listar Tipos de Baja", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogInformes: public Ui_DialogInformes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGINFORMES_H
