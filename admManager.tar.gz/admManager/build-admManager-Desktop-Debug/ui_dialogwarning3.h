/********************************************************************************
** Form generated from reading UI file 'dialogwarning3.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGWARNING3_H
#define UI_DIALOGWARNING3_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogWarning3
{
public:
    QPushButton *pushButton;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QFrame *line;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogWarning3)
    {
        if (DialogWarning3->objectName().isEmpty())
            DialogWarning3->setObjectName(QString::fromUtf8("DialogWarning3"));
        DialogWarning3->resize(400, 300);
        pushButton = new QPushButton(DialogWarning3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(90, 50, 191, 71));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/status/dialog-warning.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(32, 32));
        widget = new QWidget(DialogWarning3);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(110, 140, 141, 61));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        line = new QFrame(widget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-ok.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_2->setIcon(icon1);

        verticalLayout->addWidget(pushButton_2);


        retranslateUi(DialogWarning3);

        QMetaObject::connectSlotsByName(DialogWarning3);
    } // setupUi

    void retranslateUi(QDialog *DialogWarning3)
    {
        DialogWarning3->setWindowTitle(QApplication::translate("DialogWarning3", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogWarning3", "Connection Failure...", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DialogWarning3", "Aceptar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogWarning3: public Ui_DialogWarning3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGWARNING3_H
