/********************************************************************************
** Form generated from reading UI file 'dialogwarning2.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGWARNING2_H
#define UI_DIALOGWARNING2_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogWarning2
{
public:
    QPushButton *pushButton;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QFrame *line;
    QPushButton *aceptar;

    void setupUi(QDialog *DialogWarning2)
    {
        if (DialogWarning2->objectName().isEmpty())
            DialogWarning2->setObjectName(QString::fromUtf8("DialogWarning2"));
        DialogWarning2->resize(370, 208);
        pushButton = new QPushButton(DialogWarning2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(60, 30, 241, 81));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/document-export-table.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(32, 32));
        widget = new QWidget(DialogWarning2);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(100, 120, 161, 51));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        line = new QFrame(widget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        aceptar = new QPushButton(widget);
        aceptar->setObjectName(QString::fromUtf8("aceptar"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-ok.png"), QSize(), QIcon::Active, QIcon::On);
        aceptar->setIcon(icon1);

        verticalLayout->addWidget(aceptar);


        retranslateUi(DialogWarning2);

        QMetaObject::connectSlotsByName(DialogWarning2);
    } // setupUi

    void retranslateUi(QDialog *DialogWarning2)
    {
        DialogWarning2->setWindowTitle(QApplication::translate("DialogWarning2", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogWarning2", "Connection Succesfully...", 0, QApplication::UnicodeUTF8));
        aceptar->setText(QApplication::translate("DialogWarning2", "Aceptar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogWarning2: public Ui_DialogWarning2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGWARNING2_H
