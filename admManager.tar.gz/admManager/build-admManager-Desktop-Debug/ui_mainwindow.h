/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAbrir;
    QAction *actionNuevo;
    QAction *actionGuardar;
    QAction *actionGuardar_Como;
    QAction *actionImprimir;
    QAction *actionVista_Previa;
    QAction *actionCerrar;
    QAction *actionSalir;
    QAction *actionCortar;
    QAction *actionCopiar;
    QAction *actionPegar;
    QAction *actionSeleccionar_Todo;
    QAction *actionEliminar;
    QAction *actionAcerca_de;
    QWidget *centralWidget;
    QLabel *label;
    QFrame *line;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *mAltas;
    QPushButton *mMod;
    QPushButton *MBajas;
    QPushButton *mInfo;
    QPushButton *mSueldos;
    QLabel *sueldos;
    QLabel *footer;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QPushButton *salir;
    QMenuBar *menuBar;
    QMenu *menuArchivo;
    QMenu *menuEditar;
    QMenu *menuAyuda;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1024, 768);
        actionAbrir = new QAction(MainWindow);
        actionAbrir->setObjectName(QString::fromUtf8("actionAbrir"));
        actionNuevo = new QAction(MainWindow);
        actionNuevo->setObjectName(QString::fromUtf8("actionNuevo"));
        actionGuardar = new QAction(MainWindow);
        actionGuardar->setObjectName(QString::fromUtf8("actionGuardar"));
        actionGuardar_Como = new QAction(MainWindow);
        actionGuardar_Como->setObjectName(QString::fromUtf8("actionGuardar_Como"));
        actionImprimir = new QAction(MainWindow);
        actionImprimir->setObjectName(QString::fromUtf8("actionImprimir"));
        actionVista_Previa = new QAction(MainWindow);
        actionVista_Previa->setObjectName(QString::fromUtf8("actionVista_Previa"));
        actionCerrar = new QAction(MainWindow);
        actionCerrar->setObjectName(QString::fromUtf8("actionCerrar"));
        actionSalir = new QAction(MainWindow);
        actionSalir->setObjectName(QString::fromUtf8("actionSalir"));
        actionCortar = new QAction(MainWindow);
        actionCortar->setObjectName(QString::fromUtf8("actionCortar"));
        actionCopiar = new QAction(MainWindow);
        actionCopiar->setObjectName(QString::fromUtf8("actionCopiar"));
        actionPegar = new QAction(MainWindow);
        actionPegar->setObjectName(QString::fromUtf8("actionPegar"));
        actionSeleccionar_Todo = new QAction(MainWindow);
        actionSeleccionar_Todo->setObjectName(QString::fromUtf8("actionSeleccionar_Todo"));
        actionEliminar = new QAction(MainWindow);
        actionEliminar->setObjectName(QString::fromUtf8("actionEliminar"));
        actionAcerca_de = new QAction(MainWindow);
        actionAcerca_de->setObjectName(QString::fromUtf8("actionAcerca_de"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(150, 20, 661, 41));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setFrameShape(QFrame::StyledPanel);
        label->setFrameShadow(QFrame::Sunken);
        label->setAlignment(Qt::AlignCenter);
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(177, 70, 611, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(270, 130, 741, 61));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(7);
        label_2->setFont(font1);
        label_2->setContextMenuPolicy(Qt::DefaultContextMenu);
        label_2->setFrameShape(QFrame::StyledPanel);
        label_2->setFrameShadow(QFrame::Sunken);
        label_2->setScaledContents(true);
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(270, 200, 741, 61));
        sizePolicy.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy);
        label_3->setFont(font1);
        label_3->setContextMenuPolicy(Qt::DefaultContextMenu);
        label_3->setFrameShape(QFrame::StyledPanel);
        label_3->setFrameShadow(QFrame::Sunken);
        label_3->setScaledContents(true);
        label_3->setAlignment(Qt::AlignCenter);
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(270, 280, 741, 61));
        sizePolicy.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy);
        label_4->setFont(font1);
        label_4->setContextMenuPolicy(Qt::DefaultContextMenu);
        label_4->setFrameShape(QFrame::StyledPanel);
        label_4->setFrameShadow(QFrame::Sunken);
        label_4->setScaledContents(true);
        label_4->setAlignment(Qt::AlignCenter);
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(270, 350, 741, 61));
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);
        label_5->setFont(font1);
        label_5->setContextMenuPolicy(Qt::DefaultContextMenu);
        label_5->setFrameShape(QFrame::StyledPanel);
        label_5->setFrameShadow(QFrame::Sunken);
        label_5->setScaledContents(true);
        label_5->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(270, 420, 741, 61));
        sizePolicy.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy);
        label_6->setFont(font1);
        label_6->setContextMenuPolicy(Qt::DefaultContextMenu);
        label_6->setFrameShape(QFrame::StyledPanel);
        label_6->setFrameShadow(QFrame::Sunken);
        label_6->setScaledContents(true);
        label_6->setAlignment(Qt::AlignCenter);
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(80, 100, 197, 411));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        mAltas = new QPushButton(layoutWidget);
        mAltas->setObjectName(QString::fromUtf8("mAltas"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/dialog-ok-apply.png"), QSize(), QIcon::Active, QIcon::Off);
        mAltas->setIcon(icon);
        mAltas->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(mAltas);

        mMod = new QPushButton(layoutWidget);
        mMod->setObjectName(QString::fromUtf8("mMod"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/view-time-schedule-edit.png"), QSize(), QIcon::Active, QIcon::Off);
        icon1.addFile(QString::fromUtf8("pix/editUser2x64.png"), QSize(), QIcon::Active, QIcon::On);
        mMod->setIcon(icon1);
        mMod->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(mMod);

        MBajas = new QPushButton(layoutWidget);
        MBajas->setObjectName(QString::fromUtf8("MBajas"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/irc-remove-operator.png"), QSize(), QIcon::Active, QIcon::Off);
        icon2.addFile(QString::fromUtf8("pix/downx64.png"), QSize(), QIcon::Active, QIcon::On);
        MBajas->setIcon(icon2);
        MBajas->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(MBajas);

        mInfo = new QPushButton(layoutWidget);
        mInfo->setObjectName(QString::fromUtf8("mInfo"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/view-list-details.png"), QSize(), QIcon::Active, QIcon::Off);
        icon3.addFile(QString::fromUtf8("pix/listedx64.png"), QSize(), QIcon::Active, QIcon::On);
        mInfo->setIcon(icon3);
        mInfo->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(mInfo);

        mSueldos = new QPushButton(layoutWidget);
        mSueldos->setObjectName(QString::fromUtf8("mSueldos"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/view-loan-asset.png"), QSize(), QIcon::Active, QIcon::Off);
        icon4.addFile(QString::fromUtf8("pix/salary.png"), QSize(), QIcon::Active, QIcon::On);
        mSueldos->setIcon(icon4);
        mSueldos->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(mSueldos);

        sueldos = new QLabel(centralWidget);
        sueldos->setObjectName(QString::fromUtf8("sueldos"));
        sueldos->setGeometry(QRect(20, 430, 51, 31));
        footer = new QLabel(centralWidget);
        footer->setObjectName(QString::fromUtf8("footer"));
        footer->setGeometry(QRect(80, 530, 41, 51));
        footer->setFrameShape(QFrame::NoFrame);
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(770, 520, 221, 141));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/view-categories.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon5);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout_2->addWidget(pushButton);

        salir = new QPushButton(widget);
        salir->setObjectName(QString::fromUtf8("salir"));
        salir->setAutoFillBackground(false);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::On);
        salir->setIcon(icon6);
        salir->setIconSize(QSize(22, 22));
        salir->setAutoDefault(true);

        verticalLayout_2->addWidget(salir);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1024, 20));
        menuArchivo = new QMenu(menuBar);
        menuArchivo->setObjectName(QString::fromUtf8("menuArchivo"));
        menuEditar = new QMenu(menuBar);
        menuEditar->setObjectName(QString::fromUtf8("menuEditar"));
        menuAyuda = new QMenu(menuBar);
        menuAyuda->setObjectName(QString::fromUtf8("menuAyuda"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuArchivo->menuAction());
        menuBar->addAction(menuEditar->menuAction());
        menuBar->addAction(menuAyuda->menuAction());
        menuArchivo->addAction(actionAbrir);
        menuArchivo->addAction(actionNuevo);
        menuArchivo->addAction(actionGuardar);
        menuArchivo->addAction(actionGuardar_Como);
        menuArchivo->addSeparator();
        menuArchivo->addAction(actionImprimir);
        menuArchivo->addAction(actionVista_Previa);
        menuArchivo->addSeparator();
        menuArchivo->addAction(actionCerrar);
        menuArchivo->addSeparator();
        menuArchivo->addAction(actionSalir);
        menuEditar->addAction(actionCortar);
        menuEditar->addAction(actionCopiar);
        menuEditar->addAction(actionPegar);
        menuEditar->addSeparator();
        menuEditar->addAction(actionSeleccionar_Todo);
        menuEditar->addSeparator();
        menuEditar->addAction(actionEliminar);
        menuAyuda->addAction(actionAcerca_de);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionAbrir->setText(QApplication::translate("MainWindow", "Abrir", 0, QApplication::UnicodeUTF8));
        actionNuevo->setText(QApplication::translate("MainWindow", "Nuevo", 0, QApplication::UnicodeUTF8));
        actionGuardar->setText(QApplication::translate("MainWindow", "Guardar", 0, QApplication::UnicodeUTF8));
        actionGuardar_Como->setText(QApplication::translate("MainWindow", "Guardar Como", 0, QApplication::UnicodeUTF8));
        actionImprimir->setText(QApplication::translate("MainWindow", "Imprimir", 0, QApplication::UnicodeUTF8));
        actionVista_Previa->setText(QApplication::translate("MainWindow", "Vista Previa", 0, QApplication::UnicodeUTF8));
        actionCerrar->setText(QApplication::translate("MainWindow", "Cerrar", 0, QApplication::UnicodeUTF8));
        actionSalir->setText(QApplication::translate("MainWindow", "Salir", 0, QApplication::UnicodeUTF8));
        actionCortar->setText(QApplication::translate("MainWindow", "Cortar", 0, QApplication::UnicodeUTF8));
        actionCopiar->setText(QApplication::translate("MainWindow", "Copiar", 0, QApplication::UnicodeUTF8));
        actionPegar->setText(QApplication::translate("MainWindow", "Pegar", 0, QApplication::UnicodeUTF8));
        actionSeleccionar_Todo->setText(QApplication::translate("MainWindow", "Seleccionar Todo", 0, QApplication::UnicodeUTF8));
        actionEliminar->setText(QApplication::translate("MainWindow", "Eliminar", 0, QApplication::UnicodeUTF8));
        actionAcerca_de->setText(QApplication::translate("MainWindow", "Acerca de...", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "Bienvenido a Administration Manager. Software de Gesti\303\263n de los Recursos Humanos.", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "Aqu\303\255 podr\303\241 dar de Altas a Empleados, como tambien cualquiera de los listados restantes que se utilizaran dentro de Administration Manager.", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "Modulo en el que podr\303\241 realizar modificaciones sobre los datos de Empleados, etc.", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "Bajas correspondientes a Empleados y dem\303\241s datos contenidos en listados.", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "Completo listado de informes", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "Modulo espec\303\255fico para realizar liquidaci\303\263n de Hab\303\251res, Vacaciones, Aguinaldo y Remuneraci\303\263n final.-", 0, QApplication::UnicodeUTF8));
        mAltas->setText(QApplication::translate("MainWindow", "Modulo Altas", 0, QApplication::UnicodeUTF8));
        mMod->setText(QApplication::translate("MainWindow", "Modulo Modificaciones", 0, QApplication::UnicodeUTF8));
        MBajas->setText(QApplication::translate("MainWindow", "Modulo Bajas", 0, QApplication::UnicodeUTF8));
        mInfo->setText(QApplication::translate("MainWindow", "Modulo Informes", 0, QApplication::UnicodeUTF8));
        mSueldos->setText(QApplication::translate("MainWindow", "Modulo Sueldos", 0, QApplication::UnicodeUTF8));
        sueldos->setText(QString());
        footer->setText(QString());
        pushButton->setText(QApplication::translate("MainWindow", "Administration Manager", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("MainWindow", "Salir", 0, QApplication::UnicodeUTF8));
        menuArchivo->setTitle(QApplication::translate("MainWindow", "Archivo", 0, QApplication::UnicodeUTF8));
        menuEditar->setTitle(QApplication::translate("MainWindow", "Editar", 0, QApplication::UnicodeUTF8));
        menuAyuda->setTitle(QApplication::translate("MainWindow", "Ayuda", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
