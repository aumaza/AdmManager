/********************************************************************************
** Form generated from reading UI file 'dialogmod.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMOD_H
#define UI_DIALOGMOD_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogMod
{
public:
    QLabel *label;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogMod)
    {
        if (DialogMod->objectName().isEmpty())
            DialogMod->setObjectName(QString::fromUtf8("DialogMod"));
        DialogMod->resize(400, 300);
        label = new QLabel(DialogMod);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 20, 221, 31));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setFrameShape(QFrame::StyledPanel);
        label->setFrameShadow(QFrame::Sunken);
        label->setAlignment(Qt::AlignCenter);
        widget = new QWidget(DialogMod);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(130, 90, 161, 81));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);


        retranslateUi(DialogMod);

        QMetaObject::connectSlotsByName(DialogMod);
    } // setupUi

    void retranslateUi(QDialog *DialogMod)
    {
        DialogMod->setWindowTitle(QApplication::translate("DialogMod", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogMod", "Modulo Modificaciones", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogMod", "Editar Empleados", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DialogMod", "Editar Categorias", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogMod: public Ui_DialogMod {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMOD_H
