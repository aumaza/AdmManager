/********************************************************************************
** Form generated from reading UI file 'dialogwarning1.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGWARNING1_H
#define UI_DIALOGWARNING1_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogWarning1
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer;
    QPushButton *aceptar;

    void setupUi(QDialog *DialogWarning1)
    {
        if (DialogWarning1->objectName().isEmpty())
            DialogWarning1->setObjectName(QString::fromUtf8("DialogWarning1"));
        DialogWarning1->resize(400, 300);
        widget = new QWidget(DialogWarning1);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(60, 50, 271, 191));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-ok-apply.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(32, 32));

        verticalLayout->addWidget(pushButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        aceptar = new QPushButton(widget);
        aceptar->setObjectName(QString::fromUtf8("aceptar"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-ok.png"), QSize(), QIcon::Selected, QIcon::Off);
        aceptar->setIcon(icon1);

        verticalLayout->addWidget(aceptar);


        retranslateUi(DialogWarning1);

        QMetaObject::connectSlotsByName(DialogWarning1);
    } // setupUi

    void retranslateUi(QDialog *DialogWarning1)
    {
        DialogWarning1->setWindowTitle(QApplication::translate("DialogWarning1", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogWarning1", "Registro Agregado Exitosamente", 0, QApplication::UnicodeUTF8));
        aceptar->setText(QApplication::translate("DialogWarning1", "Aceptar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogWarning1: public Ui_DialogWarning1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGWARNING1_H
