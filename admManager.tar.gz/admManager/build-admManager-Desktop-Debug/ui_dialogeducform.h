/********************************************************************************
** Form generated from reading UI file 'dialogeducform.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEDUCFORM_H
#define UI_DIALOGEDUCFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogEducForm
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *agregar;
    QPushButton *salir;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *estudios;

    void setupUi(QDialog *DialogEducForm)
    {
        if (DialogEducForm->objectName().isEmpty())
            DialogEducForm->setObjectName(QString::fromUtf8("DialogEducForm"));
        DialogEducForm->resize(384, 240);
        layoutWidget = new QWidget(DialogEducForm);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(80, 170, 204, 33));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        agregar = new QPushButton(layoutWidget);
        agregar->setObjectName(QString::fromUtf8("agregar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/list-add.png"), QSize(), QIcon::Active, QIcon::On);
        agregar->setIcon(icon);
        agregar->setIconSize(QSize(22, 22));

        horizontalLayout_2->addWidget(agregar);

        salir = new QPushButton(layoutWidget);
        salir->setObjectName(QString::fromUtf8("salir"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::On);
        salir->setIcon(icon1);
        salir->setIconSize(QSize(22, 22));

        horizontalLayout_2->addWidget(salir);

        widget = new QWidget(DialogEducForm);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(60, 40, 241, 111));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-education-university.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon2);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        estudios = new QLineEdit(widget);
        estudios->setObjectName(QString::fromUtf8("estudios"));
        estudios->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(estudios);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(DialogEducForm);

        QMetaObject::connectSlotsByName(DialogEducForm);
    } // setupUi

    void retranslateUi(QDialog *DialogEducForm)
    {
        DialogEducForm->setWindowTitle(QApplication::translate("DialogEducForm", "Dialog", 0, QApplication::UnicodeUTF8));
        agregar->setText(QApplication::translate("DialogEducForm", "Agregar", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("DialogEducForm", "Salir", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogEducForm", "Alta Educaci\303\263n Formal", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogEducForm", "Nivel Estudio", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogEducForm: public Ui_DialogEducForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEDUCFORM_H
