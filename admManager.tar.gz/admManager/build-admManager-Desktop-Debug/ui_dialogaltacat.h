/********************************************************************************
** Form generated from reading UI file 'dialogaltacat.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGALTACAT_H
#define UI_DIALOGALTACAT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogAltaCat
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *agregar;
    QPushButton *salir;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *descripcion;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *salario;

    void setupUi(QDialog *DialogAltaCat)
    {
        if (DialogAltaCat->objectName().isEmpty())
            DialogAltaCat->setObjectName(QString::fromUtf8("DialogAltaCat"));
        DialogAltaCat->resize(313, 293);
        layoutWidget = new QWidget(DialogAltaCat);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(50, 230, 201, 33));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        agregar = new QPushButton(layoutWidget);
        agregar->setObjectName(QString::fromUtf8("agregar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/list-add.png"), QSize(), QIcon::Active, QIcon::On);
        agregar->setIcon(icon);
        agregar->setIconSize(QSize(22, 22));

        horizontalLayout_3->addWidget(agregar);

        salir = new QPushButton(layoutWidget);
        salir->setObjectName(QString::fromUtf8("salir"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::On);
        salir->setIcon(icon1);
        salir->setIconSize(QSize(22, 22));

        horizontalLayout_3->addWidget(salir);

        widget = new QWidget(DialogAltaCat);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(50, 40, 201, 131));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-engineering.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon2);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout_2->addWidget(pushButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        descripcion = new QLineEdit(widget);
        descripcion->setObjectName(QString::fromUtf8("descripcion"));
        descripcion->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(descripcion);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        salario = new QLineEdit(widget);
        salario->setObjectName(QString::fromUtf8("salario"));
        salario->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(salario);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(DialogAltaCat);

        QMetaObject::connectSlotsByName(DialogAltaCat);
    } // setupUi

    void retranslateUi(QDialog *DialogAltaCat)
    {
        DialogAltaCat->setWindowTitle(QApplication::translate("DialogAltaCat", "Dialog", 0, QApplication::UnicodeUTF8));
        agregar->setText(QApplication::translate("DialogAltaCat", "Agregar", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("DialogAltaCat", "Salir", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogAltaCat", "Alta Categorias", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogAltaCat", "Categoria", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogAltaCat", "Sueldo", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogAltaCat: public Ui_DialogAltaCat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGALTACAT_H
