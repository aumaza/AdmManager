/********************************************************************************
** Form generated from reading UI file 'dialoglistarestadocivil.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGLISTARESTADOCIVIL_H
#define UI_DIALOGLISTARESTADOCIVIL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogListarEstadoCivil
{
public:
    QTableWidget *tableWidget;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QFrame *line_2;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_2;
    QFrame *line;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogListarEstadoCivil)
    {
        if (DialogListarEstadoCivil->objectName().isEmpty())
            DialogListarEstadoCivil->setObjectName(QString::fromUtf8("DialogListarEstadoCivil"));
        DialogListarEstadoCivil->resize(535, 424);
        tableWidget = new QTableWidget(DialogListarEstadoCivil);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(60, 60, 411, 271));
        widget = new QWidget(DialogListarEstadoCivil);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(200, 10, 127, 40));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/meeting-attending.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton);

        line_2 = new QFrame(widget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        widget1 = new QWidget(DialogListarEstadoCivil);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(210, 340, 105, 40));
        verticalLayout_2 = new QVBoxLayout(widget1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        line = new QFrame(widget1);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line);

        pushButton_2 = new QPushButton(widget1);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/default.kde4/32x32/actions/dialog-ok.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton_2->setIcon(icon1);
        pushButton_2->setIconSize(QSize(22, 22));

        verticalLayout_2->addWidget(pushButton_2);


        retranslateUi(DialogListarEstadoCivil);

        QMetaObject::connectSlotsByName(DialogListarEstadoCivil);
    } // setupUi

    void retranslateUi(QDialog *DialogListarEstadoCivil)
    {
        DialogListarEstadoCivil->setWindowTitle(QApplication::translate("DialogListarEstadoCivil", "Dialog", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("DialogListarEstadoCivil", "Descripci\303\263n", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogListarEstadoCivil", "Estado Civil", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("DialogListarEstadoCivil", "Aceptar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogListarEstadoCivil: public Ui_DialogListarEstadoCivil {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGLISTARESTADOCIVIL_H
