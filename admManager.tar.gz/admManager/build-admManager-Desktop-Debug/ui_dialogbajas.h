/********************************************************************************
** Form generated from reading UI file 'dialogbajas.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGBAJAS_H
#define UI_DIALOGBAJAS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogBajas
{
public:
    QLabel *label;
    QPushButton *pushButton;

    void setupUi(QDialog *DialogBajas)
    {
        if (DialogBajas->objectName().isEmpty())
            DialogBajas->setObjectName(QString::fromUtf8("DialogBajas"));
        DialogBajas->resize(400, 300);
        label = new QLabel(DialogBajas);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(120, 20, 141, 31));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setFrameShape(QFrame::StyledPanel);
        label->setFrameShadow(QFrame::Sunken);
        label->setAlignment(Qt::AlignCenter);
        pushButton = new QPushButton(DialogBajas);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(140, 90, 99, 23));

        retranslateUi(DialogBajas);

        QMetaObject::connectSlotsByName(DialogBajas);
    } // setupUi

    void retranslateUi(QDialog *DialogBajas)
    {
        DialogBajas->setWindowTitle(QApplication::translate("DialogBajas", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogBajas", "Modulo Bajas", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogBajas", "Empleado", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogBajas: public Ui_DialogBajas {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGBAJAS_H
