/********************************************************************************
** Form generated from reading UI file 'dialogaltaempleado.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGALTAEMPLEADO_H
#define UI_DIALOGALTAEMPLEADO_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogAltaEmpleado
{
public:
    QWidget *widget;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *agregar;
    QPushButton *salir;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_6;
    QComboBox *nacionalidad;
    QLabel *label_7;
    QComboBox *estudios;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_10;
    QDateEdit *fecha;
    QLabel *label_11;
    QLineEdit *antiguedad;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *nombre;
    QLabel *label_3;
    QLineEdit *apellido;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_8;
    QComboBox *estadocivil;
    QLabel *label_9;
    QLineEdit *canthijos;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QLineEdit *edad;
    QLabel *label_5;
    QLineEdit *dni;

    void setupUi(QDialog *DialogAltaEmpleado)
    {
        if (DialogAltaEmpleado->objectName().isEmpty())
            DialogAltaEmpleado->setObjectName(QString::fromUtf8("DialogAltaEmpleado"));
        DialogAltaEmpleado->resize(712, 470);
        widget = new QWidget(DialogAltaEmpleado);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(280, 410, 341, 33));
        horizontalLayout_6 = new QHBoxLayout(widget);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        agregar = new QPushButton(widget);
        agregar->setObjectName(QString::fromUtf8("agregar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/list-add-user.png"), QSize(), QIcon::Active, QIcon::On);
        agregar->setIcon(icon);
        agregar->setIconSize(QSize(22, 22));

        horizontalLayout_6->addWidget(agregar);

        salir = new QPushButton(widget);
        salir->setObjectName(QString::fromUtf8("salir"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::Off);
        salir->setIcon(icon1);
        salir->setIconSize(QSize(22, 22));

        horizontalLayout_6->addWidget(salir);

        widget1 = new QWidget(DialogAltaEmpleado);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(70, 30, 581, 341));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/contact-new.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon2);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout->addWidget(pushButton);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_6 = new QLabel(widget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        nacionalidad = new QComboBox(widget1);
        nacionalidad->setObjectName(QString::fromUtf8("nacionalidad"));

        horizontalLayout_3->addWidget(nacionalidad);

        label_7 = new QLabel(widget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_3->addWidget(label_7);

        estudios = new QComboBox(widget1);
        estudios->setObjectName(QString::fromUtf8("estudios"));

        horizontalLayout_3->addWidget(estudios);


        gridLayout->addLayout(horizontalLayout_3, 2, 0, 1, 1);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_10 = new QLabel(widget1);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_5->addWidget(label_10);

        fecha = new QDateEdit(widget1);
        fecha->setObjectName(QString::fromUtf8("fecha"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(fecha->sizePolicy().hasHeightForWidth());
        fecha->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(fecha);

        label_11 = new QLabel(widget1);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout_5->addWidget(label_11);

        antiguedad = new QLineEdit(widget1);
        antiguedad->setObjectName(QString::fromUtf8("antiguedad"));
        antiguedad->setEnabled(true);
        sizePolicy.setHeightForWidth(antiguedad->sizePolicy().hasHeightForWidth());
        antiguedad->setSizePolicy(sizePolicy);
        antiguedad->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_5->addWidget(antiguedad);


        gridLayout->addLayout(horizontalLayout_5, 4, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        nombre = new QLineEdit(widget1);
        nombre->setObjectName(QString::fromUtf8("nombre"));
        nombre->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(nombre);

        label_3 = new QLabel(widget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout->addWidget(label_3);

        apellido = new QLineEdit(widget1);
        apellido->setObjectName(QString::fromUtf8("apellido"));
        apellido->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(apellido);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_8 = new QLabel(widget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_4->addWidget(label_8);

        estadocivil = new QComboBox(widget1);
        estadocivil->setObjectName(QString::fromUtf8("estadocivil"));

        horizontalLayout_4->addWidget(estadocivil);

        label_9 = new QLabel(widget1);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_4->addWidget(label_9);

        canthijos = new QLineEdit(widget1);
        canthijos->setObjectName(QString::fromUtf8("canthijos"));
        sizePolicy.setHeightForWidth(canthijos->sizePolicy().hasHeightForWidth());
        canthijos->setSizePolicy(sizePolicy);
        canthijos->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_4->addWidget(canthijos);


        gridLayout->addLayout(horizontalLayout_4, 3, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_4 = new QLabel(widget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        edad = new QLineEdit(widget1);
        edad->setObjectName(QString::fromUtf8("edad"));
        sizePolicy.setHeightForWidth(edad->sizePolicy().hasHeightForWidth());
        edad->setSizePolicy(sizePolicy);
        edad->setMaxLength(32767);
        edad->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(edad);

        label_5 = new QLabel(widget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_2->addWidget(label_5);

        dni = new QLineEdit(widget1);
        dni->setObjectName(QString::fromUtf8("dni"));
        sizePolicy.setHeightForWidth(dni->sizePolicy().hasHeightForWidth());
        dni->setSizePolicy(sizePolicy);
        dni->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(dni);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);


        retranslateUi(DialogAltaEmpleado);

        QMetaObject::connectSlotsByName(DialogAltaEmpleado);
    } // setupUi

    void retranslateUi(QDialog *DialogAltaEmpleado)
    {
        DialogAltaEmpleado->setWindowTitle(QApplication::translate("DialogAltaEmpleado", "Dialog", 0, QApplication::UnicodeUTF8));
        agregar->setText(QApplication::translate("DialogAltaEmpleado", "Agregar", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("DialogAltaEmpleado", "Salir", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogAltaEmpleado", "Alta Empleado", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("DialogAltaEmpleado", "Nacionalidad", 0, QApplication::UnicodeUTF8));
        nacionalidad->clear();
        nacionalidad->insertItems(0, QStringList()
         << QApplication::translate("DialogAltaEmpleado", "Argentina", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Brasil", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Chile", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Uruguay", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Paraguay", 0, QApplication::UnicodeUTF8)
        );
        label_7->setText(QApplication::translate("DialogAltaEmpleado", "Estudios Formales", 0, QApplication::UnicodeUTF8));
        estudios->clear();
        estudios->insertItems(0, QStringList()
         << QApplication::translate("DialogAltaEmpleado", "Primario", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Secundario Incompleto", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Secundario Completo", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Universitario Incompleto", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Universitario Completo", 0, QApplication::UnicodeUTF8)
        );
        label_10->setText(QApplication::translate("DialogAltaEmpleado", "Fecha Ingreso", 0, QApplication::UnicodeUTF8));
        fecha->setDisplayFormat(QApplication::translate("DialogAltaEmpleado", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("DialogAltaEmpleado", "Antiguedad", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogAltaEmpleado", "Nombre", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogAltaEmpleado", "Apellido", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("DialogAltaEmpleado", "Estado Civil", 0, QApplication::UnicodeUTF8));
        estadocivil->clear();
        estadocivil->insertItems(0, QStringList()
         << QApplication::translate("DialogAltaEmpleado", "Soltero/a", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Casado/a", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("DialogAltaEmpleado", "Divorciado/a", 0, QApplication::UnicodeUTF8)
        );
        label_9->setText(QApplication::translate("DialogAltaEmpleado", "Cantidad Hijos", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DialogAltaEmpleado", "Edad", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("DialogAltaEmpleado", "DNI", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogAltaEmpleado: public Ui_DialogAltaEmpleado {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGALTAEMPLEADO_H
