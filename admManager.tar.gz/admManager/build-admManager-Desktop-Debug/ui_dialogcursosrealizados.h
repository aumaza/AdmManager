/********************************************************************************
** Form generated from reading UI file 'dialogcursosrealizados.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCURSOSREALIZADOS_H
#define UI_DIALOGCURSOSREALIZADOS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDateEdit>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogCursosRealizados
{
public:
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *agregar;
    QPushButton *salir;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QComboBox *empleado;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *curso;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QDateEdit *date;

    void setupUi(QDialog *DialogCursosRealizados)
    {
        if (DialogCursosRealizados->objectName().isEmpty())
            DialogCursosRealizados->setObjectName(QString::fromUtf8("DialogCursosRealizados"));
        DialogCursosRealizados->resize(445, 359);
        layoutWidget = new QWidget(DialogCursosRealizados);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 270, 261, 33));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        agregar = new QPushButton(layoutWidget);
        agregar->setObjectName(QString::fromUtf8("agregar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/list-add.png"), QSize(), QIcon::Active, QIcon::On);
        agregar->setIcon(icon);
        agregar->setIconSize(QSize(22, 22));

        horizontalLayout_4->addWidget(agregar);

        salir = new QPushButton(layoutWidget);
        salir->setObjectName(QString::fromUtf8("salir"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/actions/dialog-close.png"), QSize(), QIcon::Active, QIcon::On);
        salir->setIcon(icon1);
        salir->setIconSize(QSize(22, 22));

        horizontalLayout_4->addWidget(salir);

        widget = new QWidget(DialogCursosRealizados);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(40, 30, 361, 191));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../../usr/share/icons/oxygen/32x32/categories/applications-education-school.png"), QSize(), QIcon::Active, QIcon::On);
        pushButton->setIcon(icon2);
        pushButton->setIconSize(QSize(22, 22));

        verticalLayout_2->addWidget(pushButton);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        empleado = new QComboBox(widget);
        empleado->setObjectName(QString::fromUtf8("empleado"));

        horizontalLayout->addWidget(empleado);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        curso = new QLineEdit(widget);
        curso->setObjectName(QString::fromUtf8("curso"));
        curso->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_2->addWidget(curso);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_3->addWidget(label_4);

        date = new QDateEdit(widget);
        date->setObjectName(QString::fromUtf8("date"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(date->sizePolicy().hasHeightForWidth());
        date->setSizePolicy(sizePolicy);
        date->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(date);


        verticalLayout->addLayout(horizontalLayout_3);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(DialogCursosRealizados);

        QMetaObject::connectSlotsByName(DialogCursosRealizados);
    } // setupUi

    void retranslateUi(QDialog *DialogCursosRealizados)
    {
        DialogCursosRealizados->setWindowTitle(QApplication::translate("DialogCursosRealizados", "Dialog", 0, QApplication::UnicodeUTF8));
        agregar->setText(QApplication::translate("DialogCursosRealizados", "Agregar", 0, QApplication::UnicodeUTF8));
        salir->setText(QApplication::translate("DialogCursosRealizados", "Salir", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("DialogCursosRealizados", "Alta Cursos Realizados", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogCursosRealizados", "Empleado", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogCursosRealizados", "Curso", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DialogCursosRealizados", "Fecha Finalizacion", 0, QApplication::UnicodeUTF8));
        date->setDisplayFormat(QApplication::translate("DialogCursosRealizados", "dd/MM/yyyy", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogCursosRealizados: public Ui_DialogCursosRealizados {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCURSOSREALIZADOS_H
