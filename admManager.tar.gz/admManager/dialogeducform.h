#ifndef DIALOGEDUCFORM_H
#define DIALOGEDUCFORM_H

#include <QDialog>

namespace Ui {
class DialogEducForm;
}

class DialogEducForm : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogEducForm(QWidget *parent = 0);
    ~DialogEducForm();

    void addEstudio();
    
private slots:
    void on_agregar_clicked();

    void on_salir_clicked();

private:
    Ui::DialogEducForm *ui;
};

#endif // DIALOGEDUCFORM_H
