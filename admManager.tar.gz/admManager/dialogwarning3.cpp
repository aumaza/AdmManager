#include "dialogwarning3.h"
#include "ui_dialogwarning3.h"

DialogWarning3::DialogWarning3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogWarning3)
{
    ui->setupUi(this);
}

DialogWarning3::~DialogWarning3()
{
    delete ui;
}

void DialogWarning3::on_pushButton_2_clicked()
{
    close();
}
