#ifndef DIALOGMOD_H
#define DIALOGMOD_H

#include <QDialog>

namespace Ui {
class DialogMod;
}

class DialogMod : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogMod(QWidget *parent = 0);
    ~DialogMod();
    
private:
    Ui::DialogMod *ui;
};

#endif // DIALOGMOD_H
