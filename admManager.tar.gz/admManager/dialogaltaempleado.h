#ifndef DIALOGALTAEMPLEADO_H
#define DIALOGALTAEMPLEADO_H

#include <QDialog>

namespace Ui {
class DialogAltaEmpleado;
}

class DialogAltaEmpleado : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltaEmpleado(QWidget *parent = 0);
    ~DialogAltaEmpleado();

    void addEmpleado();
    
private slots:
    void on_agregar_clicked();
    void on_salir_clicked();

private:
    Ui::DialogAltaEmpleado *ui;
};

#endif // DIALOGALTAEMPLEADO_H
