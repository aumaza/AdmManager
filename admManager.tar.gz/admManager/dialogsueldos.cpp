#include "dialogsueldos.h"
#include "ui_dialogsueldos.h"
#include <QPixmap>

DialogSueldos::DialogSueldos(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSueldos)
{
    ui->setupUi(this);
    setWindowTitle("Modulo Sueldos");
}

DialogSueldos::~DialogSueldos()
{
    delete ui;
}
