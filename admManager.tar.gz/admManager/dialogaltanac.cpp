#include "dialogaltanac.h"
#include "ui_dialogaltanac.h"
#include "dialogwarning1.h"
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

DialogAltaNac::DialogAltaNac(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAltaNac)
{
    ui->setupUi(this);
    setWindowTitle("Alta Nacionalidad");
}

DialogAltaNac::~DialogAltaNac()
{
    delete ui;
}

void DialogAltaNac::addNacionalidad()
{
    QString consulta;
    consulta.append("INSERT INTO nacionalidad ("
                    "descripcion"
                    ")"
                    "VALUES("
                    "'"+ui->nacionalidad->text()+"'"
                    ");");

    QSqlQuery insertar;
    insertar.prepare(consulta);

    if(insertar.exec())
    {
        //ui->statusBar->showMessage("Register has been insert Succesfully");
        qDebug() << "Register has been insert Succesfully";
    }

    else
    {
        //ui->statusBar->showMessage("ERROR! Impossible insert...");
        qDebug()<<"ERROR! Impossible insert...";
        qDebug()<<"ERROR!"<< insertar.lastError();
    }
}

void DialogAltaNac::on_agregar_clicked()
{
    addNacionalidad();
    DialogWarning1 w;
    w.exec();
    ui->nacionalidad->clear();
}

void DialogAltaNac::on_salir_clicked()
{
    close();
}
