#ifndef DIALOGLISTARCATEGORIAS_H
#define DIALOGLISTARCATEGORIAS_H

#include <QDialog>

namespace Ui {
class DialogListarCategorias;
}

class DialogListarCategorias : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarCategorias(QWidget *parent = 0);
    ~DialogListarCategorias();

    void listarCategorias();
    
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::DialogListarCategorias *ui;
};

#endif // DIALOGLISTARCATEGORIAS_H
