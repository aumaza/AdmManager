#include "dialoglistarnacionalidad.h"
#include "ui_dialoglistarnacionalidad.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogListarNacionalidad::DialogListarNacionalidad(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogListarNacionalidad)
{
    ui->setupUi(this);

    listarNacionalidad();
}

DialogListarNacionalidad::~DialogListarNacionalidad()
{
    delete ui;
}

void DialogListarNacionalidad::listarNacionalidad()
{
    QString consulta;
    consulta.append("SELECT * FROM nacionalidad");
    QSqlQuery consultar;
    consultar.prepare(consulta);


    if(consultar.exec())
    {
        //ui->message->text("All registers are shown Succesfully...Waiting for more...");

        qDebug() << "All registers are shown Succesfully";
    }

    else
    {
       // ui->message->text("ERROR! Impossible show table registers...");
        qDebug()<<"ERROR! Impossible show table registers...";
        qDebug()<<"ERROR!"<< consultar.lastError();
    }

    int fila = 0;
    ui->tableWidget->setRowCount(0);
    while(consultar.next())
    {
        ui->tableWidget->insertRow(fila);
        ui->tableWidget->setItem(fila,0,new QTableWidgetItem(consultar.value(1).toByteArray().constData()));
        ui->tableWidget->setItem(fila,1,new QTableWidgetItem(consultar.value(2).toByteArray().constData()));

        fila++;
    }
}

void DialogListarNacionalidad::on_pushButton_clicked()
{
    accept();
}
