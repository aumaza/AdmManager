#include "dialoglistareducfor.h"
#include "ui_dialoglistareducfor.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogListarEducFor::DialogListarEducFor(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogListarEducFor)
{
    ui->setupUi(this);
    listarEducFor();
}

DialogListarEducFor::~DialogListarEducFor()
{
    delete ui;
}

void DialogListarEducFor::listarEducFor()
{
    QString consulta;
    consulta.append("SELECT * FROM estudios");
    QSqlQuery consultar;
    consultar.prepare(consulta);


    if(consultar.exec())
    {
        //ui->message->text("All registers are shown Succesfully...Waiting for more...");

        qDebug() << "All registers are shown Succesfully";
    }

    else
    {
       // ui->message->text("ERROR! Impossible show table registers...");
        qDebug()<<"ERROR! Impossible show table registers...";
        qDebug()<<"ERROR!"<< consultar.lastError();
    }

    int fila = 0;
    ui->tableWidget->setRowCount(0);
    while(consultar.next())
    {
        ui->tableWidget->insertRow(fila);
        ui->tableWidget->setItem(fila,0,new QTableWidgetItem(consultar.value(1).toByteArray().constData()));
        ui->tableWidget->setItem(fila,1,new QTableWidgetItem(consultar.value(2).toByteArray().constData()));

        fila++;
    }
}

void DialogListarEducFor::on_pushButton_clicked()
{
    accept();
}
