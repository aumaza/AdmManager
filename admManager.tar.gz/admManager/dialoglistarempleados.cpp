#include "dialoglistarempleados.h"
#include "ui_dialoglistarempleados.h"
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDate>
#include <QDateEdit>

DialogListarEmpleados::DialogListarEmpleados(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogListarEmpleados)
{
    ui->setupUi(this);

    mostrarEmpleados();
}

DialogListarEmpleados::~DialogListarEmpleados()
{
    delete ui;
}

void DialogListarEmpleados::mostrarEmpleados()
{
    QString consulta;
    consulta.append("SELECT * FROM empleados");
    QSqlQuery consultar;
    consultar.prepare(consulta);


    if(consultar.exec())
    {
        //ui->message->text("All registers are shown Succesfully...Waiting for more...");

        qDebug() << "All registers are shown Succesfully";
    }

    else
    {
       // ui->message->text("ERROR! Impossible show table registers...");
        qDebug()<<"ERROR! Impossible show table registers...";
        qDebug()<<"ERROR!"<< consultar.lastError();
    }

    int fila = 0;
    ui->tableWidget->setRowCount(0);
    while(consultar.next())
    {
        ui->tableWidget->insertRow(fila);
        ui->tableWidget->setItem(fila,0,new QTableWidgetItem(consultar.value(1).toByteArray().constData()));
        ui->tableWidget->setItem(fila,1,new QTableWidgetItem(consultar.value(2).toByteArray().constData()));
        ui->tableWidget->setItem(fila,2,new QTableWidgetItem(consultar.value(3).toByteArray().constData()));
        ui->tableWidget->setItem(fila,3,new QTableWidgetItem(consultar.value(4).toByteArray().constData()));
        ui->tableWidget->setItem(fila,4,new QTableWidgetItem(consultar.value(5).toByteArray().constData()));
        ui->tableWidget->setItem(fila,5,new QTableWidgetItem(consultar.value(6).toByteArray().constData()));
        ui->tableWidget->setItem(fila,6,new QTableWidgetItem(consultar.value(7).toByteArray().constData()));
        ui->tableWidget->setItem(fila,7,new QTableWidgetItem(consultar.value(8).toByteArray().constData()));
        ui->tableWidget->setItem(fila,8,new QTableWidgetItem(consultar.value(9).toByteArray().constData()));
        ui->tableWidget->setItem(fila,9,new QTableWidgetItem(consultar.value(10).toByteArray().constData()));
        ui->tableWidget->setItem(fila,10,new QTableWidgetItem(consultar.value(11).toByteArray().constData()));
        fila++;
    }
}


void DialogListarEmpleados::on_pushButton_clicked()
{
    accept();
}
