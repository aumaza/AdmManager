#ifndef DIALOGLISTAREMPLEADOS_H
#define DIALOGLISTAREMPLEADOS_H

#include <QDialog>

namespace Ui {
class DialogListarEmpleados;
}

class DialogListarEmpleados : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarEmpleados(QWidget *parent = 0);
    ~DialogListarEmpleados();

    void mostrarEmpleados();
    
private slots:



    void on_pushButton_clicked();

private:
    Ui::DialogListarEmpleados *ui;
};

#endif // DIALOGLISTAREMPLEADOS_H
