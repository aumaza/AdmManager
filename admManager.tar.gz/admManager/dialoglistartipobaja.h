#ifndef DIALOGLISTARTIPOBAJA_H
#define DIALOGLISTARTIPOBAJA_H

#include <QDialog>

namespace Ui {
class DialogListarTipoBaja;
}

class DialogListarTipoBaja : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogListarTipoBaja(QWidget *parent = 0);
    ~DialogListarTipoBaja();

    void listarTipoBaja();
    
private slots:
    void on_pushButton_2_clicked();

private:
    Ui::DialogListarTipoBaja *ui;
};

#endif // DIALOGLISTARTIPOBAJA_H
