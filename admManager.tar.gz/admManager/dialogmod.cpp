#include "dialogmod.h"
#include "ui_dialogmod.h"
#include <QPixmap>

DialogMod::DialogMod(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMod)
{
    ui->setupUi(this);
    setWindowTitle("Modulo Modificaciones");
}

DialogMod::~DialogMod()
{
    delete ui;
}
