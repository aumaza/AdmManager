#ifndef DIALOGALTANAC_H
#define DIALOGALTANAC_H

#include <QDialog>

namespace Ui {
class DialogAltaNac;
}

class DialogAltaNac : public QDialog
{
    Q_OBJECT
    
public:
    explicit DialogAltaNac(QWidget *parent = 0);
    ~DialogAltaNac();

    void addNacionalidad();
    
private slots:
    void on_agregar_clicked();

    void on_salir_clicked();

private:
    Ui::DialogAltaNac *ui;
};

#endif // DIALOGALTANAC_H
